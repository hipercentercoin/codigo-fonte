Development moved to https://gitlab.com/blacknet-ninja

https://hipercentercoin.org/ aims to continue on hipercentercoin chain.
